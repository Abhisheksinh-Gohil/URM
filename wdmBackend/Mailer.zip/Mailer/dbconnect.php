<?php 
	/**
	* Database Connection
	*/
	class dbConnect {
		private $server = 'localhost';
		private $dbname = 'mxp2278_wdm_urm';
		private $user = 'root';
		private $pass = '';

		// private $server = 'localhost';
		// private $dbname = 'kjm7989_TDG';
		// private $user = 'kjm7989_database';
		// private $pass = 'ketamodi@01';

		public function connect() {
			try {
				$conn = new PDO('mysql:host=' .$this->server .';dbname=' . $this->dbname, $this->user, $this->pass);
				$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				return $conn;
			} catch (\Exception $e) {
				echo "Database Error: " . $e->getMessage();
			}
		}
	}
 ?>