<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization ");
header("Access-Control-Allow-Methods:  *");

include 'dbconnect.php';
$objDb = new dbconnect;
$conn = $objDb->connect();


if(isset($_GET['Email']) && isset($_GET['VerificationCode']))
{
    $Email = $_GET['Email'];
    $VerificationCode = $_GET['VerificationCode'];

    $query = "SELECT * FROM User WHERE Email = :Email AND VerificationCode = :VerificationCode";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':Email', $Email);
    $stmt->bindParam(':VerificationCode', $VerificationCode);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user == null) {
        echo"
            <script>
                alert('Cannot run query');
                window.location.href='https://mxp2278.uta.cloud/demo/Mailer/register.php';
            </script>
        ";
    }
    else{
        if($user['IsVerified'] == 0){
            $update = "UPDATE User SET IsVerified= 1 WHERE Email= :Email";
            $stmt1 = $conn->prepare($update);
            $stmt1->bindParam(':Email', $Email);
            if($stmt1->execute()){
                echo"
                <script>
                    alert('User verification successful.');
                    window.location.href='https://mxp2278.uta.cloud/demo/Mailer/register.php';
                </script>
            "; 
            }
            else{
                echo"
                <script>
                    alert('User verification failed!');
                    window.location.href='https://mxp2278.uta.cloud/demo/Mailer/register.php';
                </script>
            "; 
            }
        }
        else{
            echo"
            <script>
                alert('User already verified');
                window.location.href='https://mxp2278.uta.cloud/demo/Mailer/register.php';
            </script>
        ";  
        }
    }
}