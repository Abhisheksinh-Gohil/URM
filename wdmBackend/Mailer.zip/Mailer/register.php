<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization ");
header("Access-Control-Allow-Methods:  *");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpMailer/src/Exception.php';
require 'phpMailer/src/PHPMailer.php';
require 'phpMailer/src/SMTP.php';

include 'dbconnect.php';
$objDb = new dbconnect;
$conn = $objDb->connect();

$method = $_SERVER['REQUEST_METHOD'];

if ($method === "POST") {

    $user = json_decode(file_get_contents('php://input'));

    $sql = "SELECT Email FROM User WHERE Email = :Email";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':Email', $user->Email);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user == null) {

        //User Does not exist, register user

        $VerificationCode = bin2hex((random_bytes(16)));


        $sql1 = "INSERT INTO User(UserID, FirstName, LastName, Email, Password, Role, VerificationCode) VALUES (null, :FirstName, :LastName, :Email, :Password, :Role, :VerificationCode)";
        $stmt1 = $conn->prepare($sql1);
        $stmt1->bindParam(':FirstName', $user->FirstName);
        $stmt1->bindParam(':LastName', $user->LastName);
        $Email = $user->Email;
        $stmt1->bindParam(':Email', $user->Email);
        $stmt1->bindParam(':Password', $user->Password);
        $stmt1->bindParam(':Role', $user->Role);
        $stmt1->bindParam(':VerificationCode', $VerificationCode);

        if ($stmt1->execute()) {

            $mail = new PHPMailer(true);
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'madhuri201096@gmail.com';
            $mail->Password = 'hofzfxshhidqycfl';
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;
            $mail->setFrom('madhuri201096@gmail.com');
            $mail->addAddress("mxp2278@mavs.uta.edu");
            $mail->isHTML(true);
            $mail->Subject = "Email Verification from URM Application";
            $mail->Body = "Thanks for registration!
            Click the link below to verify the email address
            <a href='https://mxp2278.uta.cloud/demo/Mailer/verifyMail.php?email=$Email&$VerificationCode'>Verify</a>";
            $mail->send();

            echo "Mail sent";
            $response = ['status' => 0, 'message' => 'Registration successful.'];
        } else {
            $response = ['status' => 0, 'message' => 'User already exists.'];
        }
    } else {
        $response = ['status' => 0, 'message' => 'User already exists.'];
    }

    echo json_encode($response);
}
